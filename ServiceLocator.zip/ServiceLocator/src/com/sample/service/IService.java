package com.sample.service;

public interface IService {
	public String getName();
	public void execute();
}
