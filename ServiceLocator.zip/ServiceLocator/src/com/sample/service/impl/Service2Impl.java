package com.sample.service.impl;

import com.sample.service.IService;

public class Service2Impl implements IService {

	@Override
	public String getName() {
		return "Service2";
	}

	@Override
	public void execute() {
		System.out.println("Executing Service 2");

	}

}
