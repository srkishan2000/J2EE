package com.sample.context;

import com.sample.service.impl.Service1Impl;
import com.sample.service.impl.Service2Impl;

public class InitialContext {
	public Object lookup(String jndiName){
		if(jndiName.equalsIgnoreCase("SERVICE1")){
			System.out.println("Looking up and Creating a new Service1 Object");
			return new Service1Impl();
		}else if(jndiName.equalsIgnoreCase("SERVICE2")){
			System.out.println("Looking up and Creating a new Service2 Object");
			return new Service2Impl();
		}
		return null;
	} 
}
