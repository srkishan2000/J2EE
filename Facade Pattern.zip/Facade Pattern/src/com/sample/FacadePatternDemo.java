package com.sample;

import com.sample.facade.ShapeFacade;

public class FacadePatternDemo {

	public static void main(String[] args) {
		// Create and Initializing Facade
		ShapeFacade facade = new ShapeFacade();
		
		// calling the facade method - drawSquare 
		facade.drawSquare();
		// calling the facade method - drawRectangle
		facade.drawRectangle();
		// calling the facade method - drawCircle
		facade.drawCircle();
	}

}
