package com.sample.implementations;

import com.sample.interfaces.IShape;

public class CircleImpl implements IShape {

	@Override
	public void Draw() {
		System.out.println("Inside Circle :: Draw Method invoked ....");
	}

}
