package com.sample.implementations;

import com.sample.interfaces.IShape;

public class SquareImpl implements IShape {

	@Override
	public void Draw() {
		System.out.println("Inside Square :: Draw Method invoked ....");
	}

}
