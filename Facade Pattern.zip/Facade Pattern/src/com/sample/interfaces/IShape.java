package com.sample.interfaces;

public interface IShape {
	public void Draw();
}
