package com.sample.facade;

import com.sample.implementations.CircleImpl;
import com.sample.implementations.RectangleImpl;
import com.sample.implementations.SquareImpl;
import com.sample.interfaces.IShape;

public class ShapeFacade {
	
	private IShape square;
	private IShape rectangle;
	private IShape circle;
	
	/**
	 * Constructor
	 */
	public ShapeFacade() {
		square = (IShape) new SquareImpl();
		rectangle = (IShape) new RectangleImpl();
		circle = (IShape) new CircleImpl();
	}

	public void drawSquare(){
		square.Draw();
	}
	
	public void drawRectangle(){
		rectangle.Draw();
	}
	
	public void drawCircle(){
		circle.Draw();
	}
}
