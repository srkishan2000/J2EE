package com.sample.dao.impl;

import java.util.ArrayList;
import java.util.List;

import com.sample.dao.IStudentDAO;
import com.sample.valueobject.Student;

public class StudentDAOImpl implements IStudentDAO {
	
	private List<Student> students;
	
	public StudentDAOImpl() {
		students = new ArrayList<Student>();
		students.add(new Student(1,"Shan"));
		students.add(new Student(2,"Sridevi"));
		students.add(new Student(3,"Srikishan"));
		students.add(new Student(4,"Visvajit"));
		students.add(new Student(5,"EXTRA ....."));
	}

	@Override
	public List<Student> getAllStudents() {
		return students;
	}

	@Override
	public Student getStudent(int rollNo) {
		return students.get(rollNo);
	}

	@Override
	public void updateStudent(Student student) {
		students.get(student.getRollNo()).setName(student.getName());
		System.out.println("Student: Roll No "+ student.getRollNo() +", updated in the database");
		
	}

	@Override
	public void deleteStudent(Student student) {
		students.remove(student.getRollNo()-1);
		System.out.println("Student: Roll No " + student.getRollNo() +", deleted from database");
	}

}
