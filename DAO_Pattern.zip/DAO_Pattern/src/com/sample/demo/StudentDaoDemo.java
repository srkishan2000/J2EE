package com.sample.demo;

import com.sample.dao.IStudentDAO;
import com.sample.dao.impl.StudentDAOImpl;
import com.sample.valueobject.Student;

public class StudentDaoDemo {
	public static void main(String[] args) {
		IStudentDAO studentDao = new StudentDAOImpl();

		  //View all students	
		  viewAll(studentDao);
		
	      //update student 1
	      Student student = studentDao.getStudent(0);
	      student.setName("Shanmugam");
	      studentDao.updateStudent(student);

	      //get student 1
	      student = studentDao.getStudent(0);
	      System.out.println("Student: [RollNo : "+student.getRollNo()+", Name : "+student.getName()+" ]");
	      
	      //delete Student 5
	      Student student_ref =studentDao.getStudent(4);
	      studentDao.deleteStudent(student_ref);
	    
	      //View all students	
		  viewAll(studentDao);

	      
	      }
	
	private static void viewAll(IStudentDAO studentDao){
    	//print all students
	      for (Student student : studentDao.getAllStudents()) {
	         System.out.println("Student: [RollNo : "+student.getRollNo()+", Name : "+student.getName()+" ]");
	      }
	      
	      
	}
}
