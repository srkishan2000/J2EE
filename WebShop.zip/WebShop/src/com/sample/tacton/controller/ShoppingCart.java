package com.sample.tacton.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sample.tacton.webshop1.WebShop;

/**
 * Servlet implementation class ShoppingCart
 */
public class ShoppingCart extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String selectedCart = (String) request.getParameter("selectedCart");
		selectedCart = selectedCart == null ? "Shopping Cart Id : 001" : selectedCart;
		
		
		List<String> list = new ArrayList<String>();
		HashMap<String, Object> carts = new WebShop().getCarts();
		
		for (Map.Entry<String, Object> shoppingCart : carts.entrySet()) {
			System.out.println("\n"+shoppingCart.getKey());
			list.add(shoppingCart.getKey().toString());
		}
		
		System.out.println("Selected CART = "+selectedCart);
		print(request, response, carts, selectedCart);
		
		request.setAttribute("carts", list);
		RequestDispatcher rd = request.getRequestDispatcher("SelectedCart.jsp");
		rd.forward(request, response);
	}
	
	protected void print(HttpServletRequest request, HttpServletResponse response, HashMap<String, Object> carts, String selectedCart){
		if(selectedCart != null && carts.containsKey(selectedCart)){
			for (Map.Entry<String, Object> shoppingCart : carts.entrySet()) {
				if(shoppingCart.getKey().equals(selectedCart)){
					HashMap<String, Object> obj = (HashMap<String, Object>) shoppingCart.getValue();
					for(Map.Entry<String, Object> cap : obj.entrySet()){
						if(cap.getKey().equals("customer")){
							request.setAttribute("customer", cap.getValue());
						}else if(cap.getKey().equals("products")){
							request.setAttribute("products", cap.getValue());
						}
					}
				}
			}
		}
	}
	
	

}
