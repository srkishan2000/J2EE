package com.sample.tacton.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sample.tacton.webshop1.Organization;

/**
 * Servlet implementation class OganizationChart
 */
public class OganizationChart extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Integer noOfChilds = 0;
	private HashMap<Integer, Integer> findLocation = new HashMap<Integer, Integer>();
	private List<Organization> childOrgList = new ArrayList<Organization>();

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		request.setAttribute("orgList", initOrganization());
		request.setAttribute("findLocation", findLocation);
		request.setAttribute("noOfCol", noOfChilds);
		RequestDispatcher rd = request
				.getRequestDispatcher("OrganizationView.jsp");
		rd.forward(request, response);
	}

	protected List<Organization> initOrganization() {
		List<Organization> orgList = new ArrayList<Organization>();
		orgList.add(new Organization(1, "Root Organization", 0));
		orgList.add(new Organization(2, "Sub Organization 1", 1));
		orgList.add(new Organization(3, "Sub Organization 2", 2));
		orgList.add(new Organization(4, "Sub Organization 3", 2));
		orgList.add(new Organization(5, "Sub Organization 4", 1));
		orgList.add(new Organization(6, "Sub Organization 5", 3));
		orgList.add(new Organization(7, "Sub Organization 6", 1));
		orgList.add(new Organization(8, "Sub Organization 7", 4));
		orgList.add(new Organization(9, "Sub Organization 8", 2));
		orgList.add(new Organization(10, "Sub Organization 9", 8));
		orgList.add(new Organization(11, "Sub Organization 10", 7));
		orgList.add(new Organization(12, "Sub Organization 11", 5));

		Collections.sort(orgList, new Comparator<Organization>() {
			public int compare(Organization o1, Organization o2) {
				return o1.getParentOrganisation().compareTo(
						o2.getParentOrganisation());
			}
		});

		List<Organization> newList = new ArrayList<Organization>();

		int parentID = (Integer) orgList.get(0).getOrganizationId();
		newList.add(orgList.get(0));
		if (hasChildren(orgList, parentID)) {
			childOrgList.clear();
			newList.addAll(fetchChildrens(orgList, parentID));
		}
		
		findLocation(orgList);
		noOfChilds = noOfChildrens(findLocation);
//		System.out.println("find Location : "+findLocation.toString());
//		System.out.println("noofChilds : "+noOfChilds);
		return newList;
	}

	protected boolean hasChildren(List<Organization> orgList, int parentID){
		boolean hasChildren = false;
		for(Organization org : orgList){
			if(org.getParentOrganisation().equals(parentID)){
				hasChildren = true;
			break;
			}
		}
		return hasChildren;
	}
	
	protected List<Organization> fetchChildrens(List<Organization> orgList, int parentID){
		for(Organization org : orgList){
			if(org.getParentOrganisation().equals(parentID)){
				childOrgList.add(org);
				if(hasChildren(orgList, org.getOrganizationId())){
					fetchChildrens(orgList, org.getOrganizationId());
				}else{
					continue;
				}
			}
		}
		return childOrgList;
	}
	
	protected void findLocation(List<Organization> orgList){
		for (Organization org : orgList) {
			getLevel(orgList, org.getOrganizationId(),0);
			findLocation.put(org.getOrganizationId(), orgLevel);
			orgLevel = 0;
		}
	}
	
	private int orgLevel = 0;
	private void getLevel(List<Organization> orgList, int orgID, int level){
		for (Organization org : orgList) {
			if(org.getOrganizationId().equals(orgID)){
				level = level + 1;
				orgID = org.getParentOrganisation();
				break;
			}
		}
	
		if (orgID != 0){
			getLevel(orgList, orgID, level);
		}else{
			orgLevel = level;
		}
	}
	
	private int noOfChildrens(HashMap<Integer, Integer> findLocation){
		int childs = 0;
		for(Integer key: findLocation.keySet()){
            if (childs < findLocation.get(key)){
            	childs = (Integer) findLocation.get(key);
            }
            
        }
		return childs;
	}
}
