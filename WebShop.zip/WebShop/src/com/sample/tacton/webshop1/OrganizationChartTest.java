package com.sample.tacton.webshop1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;

public class OrganizationChartTest {

	public static void main(String[] args) {
		
		List<Organization> orgList = new ArrayList<Organization>();
		   orgList.add(new Organization(1, "Root Organization", 0));
		   orgList.add(new Organization(2, "Sub Organization 1", 1));
		   orgList.add(new Organization(3, "Sub Organization 2", 2));
		   orgList.add(new Organization(4, "Sub Organization 3", 2));
		   orgList.add(new Organization(5, "Sub Organization 4", 1));
		   orgList.add(new Organization(6, "Sub Organization 5", 3));
		   orgList.add(new Organization(7, "Sub Organization 6", 1));
		   orgList.add(new Organization(8, "Sub Organization 7", 4));
		   orgList.add(new Organization(9, "Sub Organization 8", 2));
		   orgList.add(new Organization(10, "Sub Organization 9", 8));
		   
		   Collections.sort(orgList, new Comparator<Organization>() {
				  public int compare(Organization o1, Organization o2) {
				      return o1.getParentOrganisation().compareTo(o2.getParentOrganisation());
				  }
			});
		   
		   List<Organization> newList = new ArrayList<Organization>(); 
		   
			int parentID = (Integer) orgList.get(0).getOrganizationId();
			newList.add(orgList.get(0));
			if(hasChildren(orgList, parentID)){
				newList.addAll(fetchChildrens(orgList, parentID));
			}
			
			findLocation(orgList);
//			getLevel(orgList, 10, 0);
			System.out.println("location : "+findLocation.toString());
			
		   System.out.println("\n after iterating the OLD list");
		   
		   for(Organization org : newList){
			   
			   System.out.println(org.getOrganizationId()+"    "+org.getOrganizationName()+"    "+org.getParentOrganisation());
		   }

	}
	
	
	private static boolean hasChildren(List<Organization> orgList, int parentID){
		boolean hasChildren = false;
		for(Organization org : orgList){
			if(org.getParentOrganisation().equals(parentID)){
				hasChildren = true;
				break;
			}
		}
		return hasChildren;
	}
	
	private static List<Organization> childOrgList = new ArrayList<Organization>();
	private static List<Organization> fetchChildrens(List<Organization> orgList, int parentID){
		for(Organization org : orgList){
			if(org.getParentOrganisation().equals(parentID)){
				childOrgList.add(org);
				if(hasChildren(orgList, org.getOrganizationId())){
					fetchChildrens(orgList, org.getOrganizationId());
				}else{
					continue;
				}
			}
		}
		return childOrgList;
	}
	
	
	private static HashMap<Integer, Integer> findLocation = new HashMap<Integer, Integer>();
	
	protected static void findLocation(List<Organization> orgList){
		for (Organization org : orgList) {
			System.out.println(">>>>>< : Exp Level : "+org.getOrganizationId()); //+"="+level);
			getLevel(orgList, org.getOrganizationId(),0);
			findLocation.put(org.getOrganizationId(), orgLevel);
			orgLevel = 0;
		}
	}
	
	static int orgLevel = 0;
	private static void getLevel(List<Organization> orgList, int orgID, int level){
		int organizationID = orgID;
		for (Organization org : orgList) {
			if(org.getOrganizationId().equals(orgID)){
				level = level + 1;
				orgID = org.getParentOrganisation();
				break;
			}
		}
	
		if (orgID != 0){
			getLevel(orgList, orgID, level);
		}else{
			orgLevel = level;
//			System.out.println(">>>>>< : Exp Level : "+organizationID+"="+level);
//			findLocation.put(organizationID, level);
		}
		
	}
	

}
