package com.sample.tacton.webshop1;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class WebShop {
	private static HashMap<String, Object> carts = new HashMap<String, Object>();
	
	public HashMap<String, Object> getCarts(){
		return this.carts;
	}

	public WebShop() {
		
		// Add Customer and Details
		HashMap<String, Object> customer_1 = new HashMap<String, Object>();
			customer_1.put("Name", "Shan");
			customer_1.put("Address", "Street 1, USA, florida - 11003");
			customer_1.put("Organization", "Sub Org 1");
			
		HashMap<String, Object> customer_2 = new HashMap<String, Object>();
			customer_2.put("Name", "Sund");
			customer_2.put("Address", "Rajaji 3, Singapore, Jurong - 103006");
			customer_2.put("Organization", "Sub Org 2");
		
		HashMap<String, Object> customer_3 = new HashMap<String, Object>();
			customer_3.put("Name", "Vichu");
			customer_3.put("Address", "Jackson Street 125 A, Australia, Sydney - 1234");
			customer_3.put("Organization", "Sub Org 3");
		
		HashMap<String, Object> customer_4 = new HashMap<String, Object>();
			customer_4.put("Name", "Kichu");
			customer_4.put("Address", "Kalevankatu 4 E 36, Finland, Helsinki - 00100");
			customer_4.put("Organization", "Sub Org 4");
		
		
		// Add Product and Details
		HashMap<String, Object> product_1 = new HashMap<String, Object>();
			product_1.put("Name", "ViewSonic Pro9000 Full HD Laser/LED projektori");
			product_1.put("Price �",1443.90);
			product_1.put("Light output", "1600 snow");
			product_1.put("Resolution","Full HD 1080p, 1920 x 1080");
			product_1.put("Aspect Ratio","16: 9/4: 3 / auto");
			product_1.put("Contrast ratio","100 000: 1");
			product_1.put("Laser / LED -hybridilamppu, service life","> 20 000 hours");
			product_1.put("Speakers","2 x 2W");
			product_1.put("Dark Chip 3","yes");
		
		HashMap<String, Object> product_2 = new HashMap<String, Object>();
			product_2.put("Name", "samsungS5");
			product_2.put("Price �", 599.95);
			product_2.put("GSM Frequencies", "850/900/1800 / 1900MHz");
			product_2.put("3G frequencies","850/900/1900 / 2100MHz");
			product_2.put("Grams", 145);
			
		HashMap<String, Object> product_3 = new HashMap<String, Object>();
			product_3.put("Name", "Nikon D3200 Black SLR KIT + AF-S DX 18-55 mm VR II lens");
			product_3.put("Price �", 500);
			product_3.put("shutter speeds", "1 / 4000s 30s + bulb, X-sync 1 / 200s");
			product_3.put("Focus", "11-point AF, -1 to +19 EV ...");
			product_3.put("HDMI", true);
			product_3.put("Display", "7.5 cm LCD, 921k");
			product_3.put("weight", "505 g CIPA");
			
		HashMap<String, Object> product_4 = new HashMap<String, Object>();
			product_4.put("Name", "ProCaster BH-03 Bluetooth headset");
			product_4.put("Price �", 39.90);
			product_4.put("Bluetooth", "2.1 + EDR");
			product_4.put("Battery", "Li-pol battery for up to 8 hours operating time");
			
		
		HashMap<String, Object> product_5 = new HashMap<String, Object>();
			product_5.put("Name", "Netwjork PICO -WiFi adapter");
			product_5.put("Price �", 13.90);
			product_5.put("Wifi speed", "up to 150 Mbps");
			product_5.put("USB", "True");
		
		// Add Product and Details in to the Cart1
		HashMap<String, Object> cart_1 = new HashMap<String, Object>();
		List<HashMap<String, Object>> cart1Products = new ArrayList<HashMap<String, Object>>();
			cart1Products.add(product_4);
			cart1Products.add(product_1);
			cart1Products.add(product_5);
		
			cart_1.put("customer", customer_2);
			cart_1.put("products", cart1Products);
		
		// Add Product and Details in to the Cart2
		HashMap<String, Object> cart_2 = new HashMap<String, Object>();
		List<HashMap<String, Object>> cart2Products = new ArrayList<HashMap<String, Object>>();
			cart2Products.add(product_2);
			cart2Products.add(product_3);
			cart2Products.add(product_4);
		
			cart_2.put("customer", customer_1);
			cart_2.put("products", cart2Products);
		
		// Add Product and Details in to the Cart3
		HashMap<String, Object> cart_3 = new HashMap<String, Object>();
		List<HashMap<String, Object>> cart3Products = new ArrayList<HashMap<String, Object>>();
			cart3Products.add(product_5);
			cart3Products.add(product_1);
			
			cart_3.put("customer", customer_4);
			cart_3.put("products", cart3Products);
		
		
		// Add Product and Details in to the Cart4
		HashMap<String, Object> cart_4 = new HashMap<String, Object>();
		List<HashMap<String, Object>> cart4Products = new ArrayList<HashMap<String, Object>>();
			cart4Products.add(product_4);
					
			cart_4.put("customer", customer_3);
			cart_4.put("products", cart4Products);
			
		
		// Add Product and Details in to the Cart
		HashMap<String, Object> cart_5 = new HashMap<String, Object>();
		List<HashMap<String, Object>> cart5Products = new ArrayList<HashMap<String, Object>>();
			cart5Products.add(product_2);
			cart5Products.add(product_5);
			cart5Products.add(product_4);
			cart5Products.add(product_1);
			
			cart_5.put("customer", customer_1);
			cart_5.put("products", cart5Products);
			
		// add all carts in to Carts Collection
		carts.put("Shopping Cart Id : 001", cart_1);
		carts.put("Shopping Cart Id : 002", cart_2);
		carts.put("Shopping Cart Id : 003", cart_3);
		carts.put("Shopping Cart Id : 004", cart_4);
		carts.put("Shopping Cart Id : 005", cart_5);
		
		
	}

	public static void main(String[] args) {
		HashMap<String, Object> shoppingCarts = new WebShop().getCarts();
		HashMap<String, Object> cart = new HashMap<String, Object>();
		for (Map.Entry<String, Object> shoppingCart : shoppingCarts.entrySet()) {
			System.out.println("\n"+shoppingCart.getKey());
			cart = (HashMap<String, Object>) shoppingCart.getValue();
			for (Map.Entry<String, Object> eachCart : cart.entrySet()){
				System.out.println("\n"+eachCart.getKey());
				System.out.println("\n"+eachCart.getValue());
			}
		}
	}
}
