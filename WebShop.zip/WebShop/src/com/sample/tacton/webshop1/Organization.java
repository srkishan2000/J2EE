package com.sample.tacton.webshop1;

public class Organization {
	
	private Integer organizationId;
	private String organizationName;
	private Integer parentOrganisation;
	
	public Organization(int orgId, String name, int parentId) {
		this.organizationId = orgId;
		this.organizationName = name;
		this.parentOrganisation = parentId;
	}

	public Integer getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(int organizationId) {
		this.organizationId = organizationId;
	}

	public String getOrganizationName() {
		return organizationName;
	}

	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}

	public Integer getParentOrganisation() {
		return parentOrganisation;
	}

	public void setParentOrganisation(Integer parentOrganisation) {
		this.parentOrganisation = parentOrganisation;
	}
}
