package com.sample;

import java.text.ParseException;

import javax.swing.text.MaskFormatter;

public class PhoneNumberFormat {

	public static void main(String[] args) {
		long phoneNum = 1123456789L;
	    System.out.println("+"+String.valueOf(phoneNum).replaceFirst("(\\d{1})(\\d{3})(\\d{3})(\\d+)", "$1-($2)-$3-$4"));
	    
	    
	    String phoneMask= "#-(###)-###-####";
	    String phoneNumber= "123423452345";

	    MaskFormatter maskFormatter;
		try {
			maskFormatter = new MaskFormatter(phoneMask);
			 maskFormatter.setValueContainsLiteralCharacters(false);
			 System.out.println("+"+maskFormatter.valueToString(phoneNumber) );
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	   
	}

}
