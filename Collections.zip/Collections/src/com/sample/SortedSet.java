package com.sample;

import java.util.Iterator;
import java.util.TreeSet;

public class SortedSet {

	public static void main(String[] args) {
		// Create the sorted set
	      TreeSet<String> set = new TreeSet<String>(); 

	      // Add elements to the set
	      set.add("b");
	      set.add("c");
	      set.add("a");
	      set.add("ab");

	      System.out.println("SET SIZE "+set.size());
	      System.out.println(set.contains("ab"));
	      
	      // Iterating over the elements in the set
	      Iterator<String> it = set.iterator();
	      while (it.hasNext()) {
	         // Get element
	         Object element = it.next();
	         System.out.println(element.toString());
	      }

	}

}
