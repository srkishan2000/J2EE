package com.sample;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class DaysCalculation {

	public static void main (String[] args){
		
		
		StringBuilder sb = new StringBuilder();
		sb.append("word1,");
		sb.append("word2,");
		sb.append("word3,");
		sb.append("word4,");
		
		System.out.println(sb.toString());
		
		Calendar cal1 = new GregorianCalendar();
	     Calendar cal2 = new GregorianCalendar();

	     SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyy");

	     Date date;
	     
	     try {
			date = sdf.parse("01111975");
			cal1.setTime(date);
//			date = sdf.parse("07102014");
			date = new Date();
		    cal2.setTime(date);
		} catch (ParseException e) {
			e.printStackTrace();
		}
	     

	    //cal1.set(2008, 8, 1); 
	     //cal2.set(2008, 9, 31);
	     System.out.println("Days = "+daysBetween(cal1.getTime(),cal2.getTime()));
	}
	
	public static int daysBetween(Date d1, Date d2){
        return (int)( (d2.getTime() - d1.getTime()) / (1000 * 60 * 60 * 24));
	}
	
}
