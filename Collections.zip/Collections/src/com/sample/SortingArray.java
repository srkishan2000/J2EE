package com.sample;

import java.util.ArrayList;
import java.util.Date;

public class SortingArray {

	public static void main(String[] args) {
		
		
		// display time and date using toString()
	     String str = String.format("Current Date/Time : %tc", new Date());
		System.out.println(str);
		
		
		Employee emp1 = new Employee();
		emp1.setfName("Shan");
		emp1.setlName("sund");
		
		Employee emp2 = new Employee();
		emp2.setfName("achu");
		emp2.setlName("kishan");
		
		Employee emp3 = new Employee();
		emp3.setfName("vasu");
		emp3.setlName("devi");
		
		Employee emp4 = new Employee();
		emp4.setfName("sivani");
		emp4.setlName("vichu");
		
			ArrayList<Employee> empList = new ArrayList<>();
			
			empList.add(emp1);
			empList.add(emp2);
			empList.add(emp3);
			empList.add(emp4);
			
			System.out.println(empList.contains(emp1.getfName()) && empList.contains(emp1.getlName()));
			System.out.println(" ");
			System.out.println(empList.contains(emp1) );
			System.out.println(" ");
			System.out.println("Before : "+empList.toArray());
			
			
//			Arrays.sort(empList);
			
			System.out.println(" ");
			System.out.println("After : "+empList.toArray());
		
//		    // initializing unsorted int array
//		    int iArr[] = {2, 1, 9, 6, 4};
//
//		    System.out.println("String of Array = " + Arrays.toString(iArr));
//		    
//		    // let us print all the elements available in list
//		    for (int number : iArr) {
//		      System.out.println("Number = " + number);
//		    }
//
//		    // sorting array
//		    Arrays.sort(iArr);
//
//		    // let us print all the elements available in list
//		    System.out.println("The sorted int array is:");
//		    for (int number : iArr) {
//		      System.out.println("Number = " + number);
//		    }
		
	}

}
