package com.sample.enumerator;

public class FreshJuice {
	enum FreshJuiceSize{ SMALL, MEDIUM, LARGE }
	FreshJuiceSize size;
}
