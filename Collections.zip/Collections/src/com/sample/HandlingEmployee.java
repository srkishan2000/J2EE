package com.sample;

import java.text.ParseException;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class HandlingEmployee {

	public static void main(String[] args) throws ParseException {
		
		Employees employees = new Employees();
		
		List<Employee> myList = (List<Employee>) employees.getEmployees();
		
		Collections.sort(myList, new Comparator<Employee>() {
			  public int compare(Employee o1, Employee o2) {
			      return o1.getJoin().compareTo(o2.getJoin());
			  }
		});
		
/**		
 *  Another way of collections to be sorted using without compareTo()
 *  
		Collections.sort(myList, new Comparator<MyObject> {
			   public int compare(MyObject o1, MyObject o2) {
			      DateTime a = o1.getDateTime();
			      DateTime b = o2.getDateTime();
			      if (a.lt(b)) 
			        return -1;
			      else if (a.lteq(b)) // it's equals
			         return 0;
			      else
			         return 1;
			   }
			});
			
*/			
		
		for (Employee e : employees.getEmployees()) {
			System.out.println(e.getlName()+","+e.getfName());
			System.out.println(e.getPhone().toString());
			System.out.println(e.getJoin());
		}
		
		for (Employee employee : myList) {
			if(employee != null && employee.getfName().equals("Shan"))
				System.out.println("KKKKKKKKKKKKKKKKKKKK");
		}
		
		
	}

}
