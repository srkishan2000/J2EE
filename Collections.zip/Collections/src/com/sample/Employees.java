package com.sample;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class Employees {
	private Collection<Employee> Employees;
	
	public Employees() throws ParseException {
		List<Employee> list = new ArrayList<>();
		Employee e1 = new Employee();
		Employee e2 = new Employee();
		Employee e3 = new Employee();
		Employee e4 = new Employee();
		Phone phone = new Phone();
		
		e1.setfName("Shan");
		e1.setlName("Sund");
		e1.setPhone(phone);
		e1.setJoin("1975-11-01");
		
		e2.setfName("Shan");
		e2.setlName("Kichu");
		e2.setPhone(phone);
		e2.setJoin("2000-05-24");
		
		e3.setfName("Shan");
		e3.setlName("Vichu");
		e3.setPhone(phone);
		e3.setJoin("2005-03-16");
		
		e4.setfName("Vasu");
		e4.setlName("Sridevi");
		e4.setPhone(phone);
		e4.setJoin("1976-07-21");
		
		list.add(e1);
		list.add(e2);
		list.add(e3);
		list.add(e4);
		
		setEmployees(list);
	}

	public Collection<Employee> getEmployees() {
		return Employees;
	}

	public void setEmployees(Collection<Employee> employees) {
		Employees = employees;
	}

}
