package com.sample;

import java.util.Collections;
import java.util.Vector;

public class SortedVector {

	public static void main(String[] args) {
		// Create a Vector and populate it with elements
		Vector<String> vector = new Vector<String>();
			vector.add("element_1");
			vector.add("element_3");
			vector.add("element_5");
			vector.add("element_2");
			vector.add("element_4");

		// Vector implementation maintains the insertion order for its elements
		System.out.println("Elements in Vector prior sorting :");

		for (int i = 0; i < vector.size(); i++)
			System.out.println(vector.get(i));

		System.out.println("");
		
		// Using Collection.sort static operation we can sort Vector elements in
		// ascending order
		Collections.sort(vector);

		System.out.println("Elements in Vector after sorting in Ascending order :");

		for (int i = 0; i < vector.size(); i++)
			System.out.println(vector.get(i));
		System.out.println("");
		
		System.out.println("Elements in Vector prior sorting in decending order :");
		for (int j = vector.size() - 1; j >= 0; j--)
			System.out.println(vector.get(j));
	}

}
