package com.sample;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Employee {
	private String fName;
	private String lName;
	private Phone phone;
	private Date join;
	
	/**
	 * @return the fName
	 */
	public String getfName() {
		return fName;
	}
	/**
	 * @param fName the fName to set
	 */
	public void setfName(String fName) {
		this.fName = fName;
	}
	/**
	 * @return the lName
	 */
	public String getlName() {
		return lName;
	}
	/**
	 * @param lName the lName to set
	 */
	public void setlName(String lName) {
		this.lName = lName;
	}
	/**
	 * @return
	 */
	public Phone getPhone() {
		return phone;
	}
	/**
	 * @param phone
	 */
	public void setPhone(Phone phone) {
		this.phone = phone;
	}
	/**
	 * 
	 * @return
	 */
	public Date getJoin() {
		return join;
	}
	/**
	 * 
	 * @param join
	 * @throws ParseException 
	 */
	public void setJoin(String date) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		this.join = sdf.parse(date);
	}
	

}
