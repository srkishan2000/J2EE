package com.sample;

import java.text.ParseException;

import javax.swing.text.MaskFormatter;

public class Phone {
 private int countryCode;
 private int prefix;
 private int landLine;

 public Phone() {
		this.countryCode = 1;
		this.prefix = 256;
		this.landLine = 1234567;
	}
 
 public int getCountryCode() {
	return countryCode;
}
public void setCountryCode(int countryCode) {
	this.countryCode = countryCode;
}
public int getPrefix() {
	return prefix;
}
public void setPrefix(int prefix) {
	this.prefix = prefix;
}
public int getLandLine() {
	return landLine;
}
public void setLandLine(int landLine) {
	this.landLine = landLine;
}

public String toString(){
	StringBuilder sb = new StringBuilder();
	sb.append(countryCode);
	sb.append(prefix);
	sb.append(landLine);
	
	String phoneMask= "#-(###)-###-####";
	String phoneNum = sb.toString();
	
	MaskFormatter maskFormatter;
	
	try {
		maskFormatter = new MaskFormatter(phoneMask);
		maskFormatter.setValueContainsLiteralCharacters(false);
		return "+"+maskFormatter.valueToString(phoneNum);
	} catch (ParseException e) {
		e.printStackTrace();
	}
	return "No phone";
}
 
}
