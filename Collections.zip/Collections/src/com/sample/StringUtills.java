package com.sample;

public class StringUtills {

	public static void main(String[] args) {
		String sentence = "The fox jumped over the fence";
		String[] words = sentence.split(" ");
		
		for (String word : words) {
		    System.out.print(new StringBuilder(word).reverse() + " ");
		}
		
		System.out.println("\n");
		for (int i = words.length -1; i >= 0 ; i--) {
			System.out.print(new StringBuilder(words[i])+ " ");
			
		}
		
		System.out.println("\n");
		System.out.print("reverse the sentence : "+ new StringBuilder(sentence).reverse());
	}
	
}
