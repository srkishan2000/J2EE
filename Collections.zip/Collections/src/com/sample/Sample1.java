package com.sample;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.logging.Logger;

public class Sample1 {
	
	
//	private static Collection<String> c; 
	
	static Logger log = Logger.getLogger("Sample.class");
	
	public static void main(String[] args) {
		
		String     anElement  = "an element";
		Collection collection = new HashSet();

		log.info("Added an Element in the collection : "+collection.add(anElement));
		log.info("Removed an Element in the collection : "+collection.remove(anElement));    
		
	}
	
	
	public static void doSomething(Collection collection) {
	    
		Iterator iterator = collection.iterator();
	    while(iterator.hasNext()){
	      Object object = iterator.next();
	      // do something
	    }
	  }
	
	
}
