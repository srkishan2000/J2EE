package com.sample;

import com.sample.factory.ShapeFactory;
import com.sample.interfaces.IShape;

public class FactoryPatternDemo {

	public static void main(String[] args) {
		// Create and Initializing Factory
		ShapeFactory factory = new ShapeFactory();
		
		// getting Shape interface by calling factory's getShape method
		IShape circle = factory.getShape("CIRCLE");
		// call the corresponding shape using the interface which returned by factory pattern
		circle.Draw();
		// getting Shape interface by calling factory's getShape method
		IShape rectangle = factory.getShape("RECTANGLE");
		// call the corresponding shape using the interface which returned by factory pattern
		rectangle.Draw();
		// getting Shape interface by calling factory's getShape method
		IShape square = factory.getShape("SQUARE");
		// call the corresponding shape using the interface which returned by factory pattern
		square.Draw();
	}

}
