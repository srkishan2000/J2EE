package com.sample.factory;

import com.sample.implementations.CircleImpl;
import com.sample.implementations.RectangleImpl;
import com.sample.implementations.SquareImpl;
import com.sample.interfaces.IShape;

public class ShapeFactory {
	public IShape getShape(String shapeType){
		if(shapeType.equalsIgnoreCase("SQUARE")){
			return (IShape) new SquareImpl();
		}else if(shapeType.equalsIgnoreCase("RECTANGLE")){
			return (IShape) new RectangleImpl();
		}else if(shapeType.equalsIgnoreCase("CIRCLE")){
			return (IShape) new CircleImpl();
		}
		// None of the above cases are not valid then returns null shape object. 
		return null;
	}
}
