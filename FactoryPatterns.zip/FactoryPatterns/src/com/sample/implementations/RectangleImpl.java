package com.sample.implementations;

import com.sample.interfaces.IShape;

public class RectangleImpl implements IShape {

	@Override
	public void Draw() {
		System.out.println("Inside Rectangle :: Draw Method invoked ....");
	}

}
