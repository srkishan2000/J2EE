package com.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.controller.view.View;

/**
 * @author ganesansh
 *
 */
public class LoginController implements Controller {

	/* (non-Javadoc)
	 * @see com.controller.Controller#execute(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	public View execute(HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		return new View("/login.jsp");
	}

}
