package com.controller.config;

import com.controller.Controller;

import static java.lang.Class.forName;

/**
 * @author ganesansh
 *
 */
public class ControllerConfig {
	
	private String action;
	private String controllerClass;
	/**
	 * @param action
	 * @param controllerClass
	 */
	public ControllerConfig(String action, String controllerClass) {
		this.action = action;
		this.controllerClass = controllerClass;
	}
	/**
	 * @return Controller
	 */
	public Controller invokeController(){
		Controller controller = null;
		if(controllerClass != null && !controllerClass.isEmpty()){
			try {
				controller = (Controller) forName(controllerClass).newInstance();
			} catch (InstantiationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return controller;
	}
	/**
	 * @return the action
	 */
	public String getAction() {
		return action;
	}
	/**
	 * @param action the action to set
	 */
	public void setAction(String action) {
		this.action = action;
	}
	/**
	 * @return the controllerClass
	 */
	public String getControllerClass() {
		return controllerClass;
	}
	/**
	 * @param controllerClass the controllerClass to set
	 */
	public void setControllerClass(String controllerClass) {
		this.controllerClass = controllerClass;
	}

}
