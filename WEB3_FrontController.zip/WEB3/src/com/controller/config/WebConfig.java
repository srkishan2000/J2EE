package com.controller.config;

import static java.lang.String.format;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.jboss.logging.Logger;

/**
 * @author ganesansh
 *
 */
public final class WebConfig {
	// TODO Enumerator implementation in future.
	private static final String MAPPING = "mappings.properties";
	private Map<String, ControllerConfig> controllers = null;
	private Logger logger = Logger.getLogger("WebConfig");
	
	/**
	 * @param mappingFile
	 */
	public WebConfig(String mappingFile) {
		File mapping = new File(mappingFile);
		logger.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> : "+mapping.getPath());
		if(mapping.isFile() && mapping.exists()){
			String fileName = mapping.getName();
			if(!fileName.equals(MAPPING)){
				throw new UnsupportedOperationException(format("mapping file name should be %s.",MAPPING));
			}
			controllers = new HashMap<String, ControllerConfig>();
			readMappingFile(mapping);
		}else{
			// TODO Logger implementation in future. 
			System.err.println("Not a mapping file or not Exists... "+mapping.getPath());
		}
	}
	/**
	 * @param propFile
	 */
	private void readMappingFile(File propFile){
		Properties props = new Properties();
		try {
			props.load(new FileInputStream(propFile));
			Set<Object> keys = props.keySet();
			Iterator<Object> it = keys.iterator();
			while (it.hasNext()) {
				String key = (String) it.next();
				String className = (String) props.get(key);
				ControllerConfig cc = new ControllerConfig(key, className);
				addControllerConfig(key, cc);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * @param actionURL
	 * @param controllerConf
	 */
	private void addControllerConfig(String actionURL, ControllerConfig controllerConf){
		if(!controllers.containsKey(actionURL)){
			controllers.put(actionURL, controllerConf);
		}else{
			throw new UnsupportedOperationException(format("Action %s is already exists. "+"Two controllers can't map to one action.", actionURL));
		}
	}
	/**
	 * @return the controllers
	 */
	public Map<String, ControllerConfig> getControllers() {
		return controllers;
	}
}
