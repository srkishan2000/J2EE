package com.controller;

import java.io.IOException;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jboss.logging.Logger;

import com.controller.config.ControllerConfig;
import com.controller.config.WebConfig;
import com.controller.view.View;

/**
 * Servlet implementation class AppServlet
 */
@WebServlet(
		description = "Front_Controller_Application_Servlet", 
		loadOnStartup = 1, 
		urlPatterns = { "*.do" }, 
		initParams = {
				@WebInitParam (name = "mapping", value="/WEB-INF/classes/properties/mappings.properties")
		}
	)
public class AppServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String MAPPING_FILE="mapping";
	private ServletContext context;
	private WebConfig webConfig =  null;
	private static Logger logger = Logger.getLogger(AppServlet.class);
       
	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		this.context = config.getServletContext();
		String mappingFile = null;
		String controllersProps = config.getInitParameter(MAPPING_FILE);
		mappingFile = context.getRealPath(controllersProps);
		webConfig = new WebConfig(mappingFile);
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcess(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcess(request, response);
	}
	/**
	 * @param request
	 * @param response
	 */
	private void doProcess(HttpServletRequest request, HttpServletResponse response){
		final String servletPath = request.getServletPath();
		final String actionPath =  servletPath.substring(1,servletPath.lastIndexOf("."));
		final Map<?, ?> controllers = webConfig.getControllers();
		final ControllerConfig controllerConfig = (ControllerConfig) controllers.get(actionPath);
		
		View view =  null;
		if(controllerConfig != null){
			String actionURL = controllerConfig.getAction();
			if(actionPath.equals(actionURL)){
				try {
					final Controller controller = controllerConfig.invokeController();
					view = controller.execute(request, response);
					prepareModelData(request, view);
					logger.info(">>>>>>>>> : request has been forwared .......");
					RequestDispatcher rd=request.getRequestDispatcher(view.getForward()); 
					rd.forward(request, response); 
//					response.sendRedirect(view.getForward());
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	private void prepareModelData(HttpServletRequest request, View view) {
		final Map<?,?> model = view.getModel();
		if(model != null){
			for(Entry<?, ?> data : model.entrySet()){
				request.setAttribute(data.getKey().toString(), data.getValue());
			}
		}
	}

}
