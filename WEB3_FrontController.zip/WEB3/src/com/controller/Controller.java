package com.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.controller.view.View;

/**
 * @author ganesansh
 *
 */
public interface Controller {
	public View execute(HttpServletRequest request, HttpServletResponse response) throws Exception;
}
