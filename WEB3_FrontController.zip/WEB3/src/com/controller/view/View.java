package com.controller.view;

import java.util.Map;

/**
 * @author ganesansh
 *
 */
public class View {
	
	private Map<?, ?> model;
	private String forward;
	
	/**
	 * @param forward
	 */
	public View(String forward) {
		this.setForward(forward);
	}
	/**
	 * @param model
	 * @param forward
	 */
	public View(Map<?, ?> model, String forward) {
		if (model != null)
			this.model = model;
		
		this.setForward(forward);
	}
	/**
	 * clean the model
	 */
	public void clean() {
		this.model = null;
	}
	/**
	 * @return the model
	 */
	public Map<?, ?> getModel() {
		return model;
	}
	/**
	 * @param model the model to set
	 */
	public void setModel(Map<?, ?> model) {
		this.model = model;
	}
	/**
	 * @return the forward
	 */
	public String getForward() {
		return forward;
	}
	/**
	 * @param forward the forward to set
	 */
	public void setForward(String forward) {
		this.forward = forward;
	}
}
